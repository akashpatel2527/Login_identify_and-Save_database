<?php require_once "include/header.php"; ?>
<?php
$single = htmlspecialchars($_SESSION["id"]);
$records = mysqli_query($link, "SELECT id,std_image,username,password FROM users WHERE id ='$single'");
while ($data = mysqli_fetch_array($records)) {
?>

<div class="container ">
<h2>Profile</h2>
  <div class="card mb-3 mt-5" style="max-width: 540px;">
  <div class="row no-gutters">
    <div class="col-md-4">
    <img src='<?php echo $data['std_image'] ?>' height='120px' width='100px'>
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">Profile</h5>
        <p class="card-text">Id :<?php echo $data['id']; ?></p>
            <p class="card-text">Username :<?php echo $data['username']; ?></p>
            <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
      </div>
    </div>
  </div>
</div>
</div>
<?php
}
?>


<?php require_once "include/footer.php"; ?>