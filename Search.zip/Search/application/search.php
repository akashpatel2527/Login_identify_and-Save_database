<html>
<body>

<form action="phpSearchOption.php" method="post">
Search <input type="text" name="search"><br>

Column: <select name="column">
	<option value="username">Name</option>
	<option value="id">Age</option>
	
	</select><br>
<input type ="submit">
</form>

</body>
</html>