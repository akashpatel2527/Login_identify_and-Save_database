
 <?php  require_once "include/header.php"; ?>
 
 
 <div class="container">
<h2>Dashboard</h2>
</div>
 <h1 style="text-align:center ; margin-top:250px">Welcome  <?php echo htmlspecialchars($_SESSION["username"]); ?></h1>

 <?php  require_once "include/footer.php"; ?>
 