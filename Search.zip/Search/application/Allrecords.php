<?php require_once "include/header.php"; check_login(); ?>
<?php

require_once('include/config.php');
?>










<div class="container mt-4">

<nav class="navbar navbar-dark bg-info">
  <form class="form-inline" action="#" method="post">
    <input class="form-control mr-sm-2" type="search" placeholder="Search" name="search" aria-label="Search">
    <button class="btn btn-warning my-2 my-sm-0" name="save" type="submit">Search</button>
  </form>
</nav> <br>
  <h2 id="front_show_li">List</h2>

  <table width="98%" align="center" cellpadding="5" cellspacing="1" border="0">
    <thead>
      <tr>
        <th width="1%">No</th>
        <th width="1%">Id</th>
        <th width="4%">Image</th>
        <th width="*">Username</th>
        <th width="2%">Edit</th>
        <th width="2%">Delete</th>
      </tr>
    </thead>
    <tbody>
   
      
    
      
      <?php
      

      $records = mysqli_query($link, "select * from users");
      while ($data = mysqli_fetch_array($records))
       {
      ?>
        <tr>
          <td></td>
          <td><?php echo $data['id']; ?></td>
          <td><img src='<?php echo $data['std_image'] ?>' height='100px' width='100px'></td>
          <td><?php echo $data['username']; ?></td>
          <!-- <td><?php echo $data['password']; ?></td>     -->
          <td><a href="form.php?edit=<?php echo $data['id']; ?>" class="btn btn-success">Edit</a></td>
          <td><a href="delete.php?id=<?php echo $data['id']; ?>">Delete</a></td>
        </tr>
      <?php
     } 
    
                    
                     
  
      ?>
         
                  
                

    </tbody>

  </table>
</div>

<?php require_once "include/footer.php"; ?>