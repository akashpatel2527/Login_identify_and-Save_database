<?php
include("developers.php");
?>
<?php  require_once "include/header.php"; ?>
<div class="container">
 <h2>Update Profile</h2> <br>
    <div class="row card">
    <h3 class="text">update your profile</h3>
      <div class="col-sm-12">
        <div class="form-img">
        <img src="" alt="">
        </div>
        <i class="fa fa-camera"></i>
        
        <p><?php echo !empty($result) ? $result : ''; ?></p>
       <form method="post">
       <div class="form-group">
       <label>Image</label>
      <input type="file"  name="std_image" value="<?php echo $editData['std_image'] ?? ''; ?>" >

          </div>
          <div class="form-group">
            <input type="text" class="form-control" placeholder="Name" name="username" value="<?php echo $editData['username'] ?? ''; ?>">
          </div>
          <!-- <div class="form-group">
            <input type="password" class="form-control" placeholder="password" name="password" value="<?php echo $editData['password'] ?? ''; ?>">
          </div> -->
        <button type="submit"name="<?php echo empty($editData) ? 'save' : 'update'; ?>" class="btn btn-primary" >Save</button>
      </form>
      </div>
    </div>
  </div>
<?php  require_once "include/footer.php"; ?>
 