<footer class="text-center"  style="margin-top:40% ;">
  <p>Footer Text</p>
</footer>

</body>
</html>
