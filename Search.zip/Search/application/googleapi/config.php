<?php

//config.php

//Include Google Client Library for PHP autoload file
require_once 'vendor/autoload.php';

//Make object of Google API Client for call Google API
$google_client = new Google_Client();

//Set the OAuth 2.0 Client ID
$google_client->setClientId('77707403959-40pskcqckb31as53thb7r5qfj2i5uc4b.apps.googleusercontent.com
');

//Set the OAuth 2.0 Client Secret key
$google_client->setClientSecret('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');

//Set the OAuth 2.0 Redirect URI
$google_client->setRedirectUri('http://localhost/Search/application/googleapi/index.php');

//
$google_client->addScope('email');

$google_client->addScope('profile');

//start session on web page
session_start();

?>