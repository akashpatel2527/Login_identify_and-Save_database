<?php require_once "include/config.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel='stylesheet' href="asset/css/style.css" type='text/css'>
  <link rel='stylesheet' href="asset/css/style1.css" type='text/css'>
  <link rel='stylesheet' href="asset/css/all_data.css" type='text/css'>

</head>

<body>

  <nav class="navbar navbar-expand-lg navbar-light bg-light">

    <img src="./asset/logo.png" alt="" class="nav-img">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <?php if (isset($_SESSION["loggedin"])) { ?>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item active">
            <a class="nav-link" href="welcome.php">Dashboard<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Allrecords.php">List</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Entry</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="search.php">Search</a>
          </li>
        </ul>
      </div>
      <form class="form-inline">
        <div class="dropdown">
          <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span><i class="fa fa-user-circle-o" style="font-size:24px"></i>
            <?php echo htmlspecialchars($_SESSION["username"]); ?>
            </span>
          </a>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <a class="dropdown-item" href="userProfile.php">Profile</a>
            <?php
$single = htmlspecialchars($_SESSION["id"]);
$records = mysqli_query($link, "SELECT id,std_image,username,password FROM users WHERE id ='$single'");
while ($data = mysqli_fetch_array($records)) {
?>

<a class="dropdown-item" href="form.php?edit=<?php echo $data['id']; ?>">Edit Profile</a>
<?php
}
?>
            <a class="dropdown-item" href="reset-password.php"><i class="fa fa-key" style="font-size:16px;color:red">Password change</i></a>
            <a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out" style="font-size:16px;color:red">Logout</i></a>
          </div>
        </div>
        </div>
      </form>
    <?php } ?>
  </nav>